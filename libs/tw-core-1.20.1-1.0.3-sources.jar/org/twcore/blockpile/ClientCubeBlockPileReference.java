package org.twcore.blockpile;

import org.jetbrains.annotations.NotNull;
import org.slf4j.Logger;
import org.twcore.TWCore;
import org.twcore.api.blockpile.CubeBlockPileReference;

import java.util.Objects;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2487;
import net.minecraft.class_2512;
import net.minecraft.class_2586;
import net.minecraft.class_2680;

/**
 * 客户端方块堆引用实现。
 * 只包含显示所需的信息，不包含实际功能，数据完全从服务器同步
 */
public class ClientCubeBlockPileReference implements CubeBlockPileReference {
    private static final Logger LOGGER = TWCore.LOGGER;

    private final class_2338 masterWorldPos;
    private final class_2338 relativePos;
    private final class_2248 baseBlock;
    private final class_2338 worldPos;
    private final int structureWidth;
    private final int structureHeight;
    private final int structureDepth;
    private boolean disposed = false;

    public ClientCubeBlockPileReference(@NotNull class_2487 nbt) {
        // 从NBT反序列化
        this.masterWorldPos = class_2512.method_10691(nbt.method_10562(MASTER_POS_KEY));
        this.relativePos = class_2512.method_10691(nbt.method_10562(RELATIVE_POS_KEY));

        String blockId = nbt.method_10558(BASE_BLOCK_KEY);
        this.baseBlock = net.minecraft.class_7923.field_41175.method_10223(net.minecraft.class_2960.method_12829(blockId));

        // 读取结构尺寸
        this.structureWidth = nbt.method_10550(STRUCTURE_WIDTH_KEY);
        this.structureHeight = nbt.method_10550(STRUCTURE_HEIGHT_KEY);
        this.structureDepth = nbt.method_10550(STRUCTURE_DEPTH_KEY);

        // 计算世界坐标
        this.worldPos = new class_2338(
                masterWorldPos.method_10263() + relativePos.method_10263(),
                masterWorldPos.method_10264() + relativePos.method_10264(),
                masterWorldPos.method_10260() + relativePos.method_10260()
        );
    }

    /**
     * 从服务端引用创建客户端引用
     */
    public static ClientCubeBlockPileReference fromServerReference(@NotNull CubeBlockPileReference serverReference) {
        if (serverReference.isDisposed()) {
            throw new IllegalArgumentException("Cannot create client reference from disposed server reference");
        }

        class_2487 nbt = serverReference.toNbt();
        // 确保包含结构尺寸信息
        if (!nbt.method_10545(STRUCTURE_WIDTH_KEY)) {
            nbt.method_10569(STRUCTURE_WIDTH_KEY, serverReference.getStructureWidth());
            nbt.method_10569(STRUCTURE_HEIGHT_KEY, serverReference.getStructureHeight());
            nbt.method_10569(STRUCTURE_DEPTH_KEY, serverReference.getStructureDepth());
        }

        return new ClientCubeBlockPileReference(nbt);
    }

    @Override
    @NotNull
    public class_2487 toNbt() {
        class_2487 nbt = new class_2487();

        // 主方块坐标
        nbt.method_10566(MASTER_POS_KEY, class_2512.method_10692(masterWorldPos));

        // 相对坐标
        nbt.method_10566(RELATIVE_POS_KEY, class_2512.method_10692(relativePos));

        // 基础方块
        if (baseBlock != null) {
            nbt.method_10582(BASE_BLOCK_KEY, net.minecraft.class_7923.field_41175.method_10221(baseBlock).toString());
        } else {
            nbt.method_10582(BASE_BLOCK_KEY, "minecraft:air");
        }

        // 结构尺寸
        nbt.method_10569(STRUCTURE_WIDTH_KEY, structureWidth);
        nbt.method_10569(STRUCTURE_HEIGHT_KEY, structureHeight);
        nbt.method_10569(STRUCTURE_DEPTH_KEY, structureDepth);

        return nbt;
    }

    @Override
    public boolean matchesBlock(class_2248 block) {
        return !disposed && baseBlock == block;
    }

    @Override
    public boolean matchesBlockState(class_2680 blockState) {
        if (blockState != null) {
            return matchesBlock(blockState.method_26204());
        }
        return false;
    }

    @Override
    public boolean matchesBlockEntity(class_2586 blockEntity) {
        if (blockEntity == null) {
            return false;
        }
        return matchesBlockState(blockEntity.method_11010());
    }

    @Override
    public boolean isMasterBlock() {
        return !disposed && relativePos.method_10263() == 0 && relativePos.method_10264() == 0 && relativePos.method_10260() == 0;
    }

    @Override
    public @NotNull class_2338 getMasterWorldPos() {
        if (disposed) {
            throw new IllegalStateException("ClientMultiBlockReference has been disposed");
        }
        return masterWorldPos;
    }

    @Override
    public @NotNull class_2338 getWorldPos() {
        if (disposed) {
            throw new IllegalStateException("ClientMultiBlockReference has been disposed");
        }
        return worldPos;
    }

    @Override
    public @NotNull class_2338 getRelativePos() {
        if (disposed) {
            throw new IllegalStateException("ClientMultiBlockReference has been disposed");
        }
        return relativePos;
    }

    @Override
    public @NotNull class_2248 getBaseBlock() {
        if (disposed) {
            throw new IllegalStateException("ClientMultiBlockReference has been disposed");
        }
        return baseBlock;
    }

    @Override
    public int getVolume() {
        return disposed ? 0 : structureWidth * structureHeight * structureDepth;
    }

    @Override
    public boolean containsWorldPos(@NotNull class_2338 worldPos) {
        if (disposed) return false;

        class_2338 endPos = new class_2338(
                masterWorldPos.method_10263() + structureWidth - 1,
                masterWorldPos.method_10264() + structureHeight - 1,
                masterWorldPos.method_10260() + structureDepth - 1
        );

        return worldPos.method_10263() >= masterWorldPos.method_10263() && worldPos.method_10263() <= endPos.method_10263() &&
                worldPos.method_10264() >= masterWorldPos.method_10264() && worldPos.method_10264() <= endPos.method_10264() &&
                worldPos.method_10260() >= masterWorldPos.method_10260() && worldPos.method_10260() <= endPos.method_10260();
    }

    @Override
    public boolean checkIntegrity() {
        // 客户端无法检查完整性，默认返回true
        return !disposed;
    }

    @Override
    public boolean isDisposed() {
        return disposed;
    }

    @Override
    public boolean isValid() {
        return !disposed && masterWorldPos != null && relativePos != null && baseBlock != null &&
                structureWidth > 0 && structureHeight > 0 && structureDepth > 0;
    }

    @Override
    public void dispose() {
        disposed = true;
    }

    @Override
    public int getRelativeX() {
        return relativePos.method_10263();
    }

    @Override
    public int getRelativeY() {
        return relativePos.method_10264();
    }

    @Override
    public int getRelativeZ() {
        return relativePos.method_10260();
    }

    @Override
    public int getStructureWidth() {
        return structureWidth;
    }

    @Override
    public int getStructureHeight() {
        return structureHeight;
    }

    @Override
    public int getStructureDepth() {
        return structureDepth;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        ClientCubeBlockPileReference that = (ClientCubeBlockPileReference) obj;
        return Objects.equals(masterWorldPos, that.masterWorldPos) &&
                Objects.equals(relativePos, that.relativePos) &&
                Objects.equals(baseBlock, that.baseBlock);
    }

    @Override
    public int hashCode() {
        return Objects.hash(masterWorldPos, relativePos, baseBlock);
    }

    @Override
    public String toString() {
        return String.format("ClientMultiBlockReference{masterPos=%s, relativePos=%s, worldPos=%s, isMaster=%b, size=%dx%dx%d}",
                masterWorldPos, relativePos, worldPos, isMasterBlock(), structureWidth, structureHeight, structureDepth);
    }
}