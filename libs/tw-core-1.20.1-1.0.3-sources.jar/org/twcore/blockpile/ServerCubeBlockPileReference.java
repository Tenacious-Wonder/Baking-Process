package org.twcore.blockpile;

import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.slf4j.Logger;
import org.twcore.TWCore;
import org.twcore.api.blockpile.CubeBlockPile;
import org.twcore.api.blockpile.CubeBlockPileReference;

import java.util.Objects;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2487;
import net.minecraft.class_2512;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_2960;
import net.minecraft.class_4538;

/**
 * 服务端方块堆引用实现
 */
public class ServerCubeBlockPileReference implements CubeBlockPileReference {
    private static final Logger LOGGER = TWCore.LOGGER;

    private final CubeBlockPile cubeBlockPile;
    private final class_2338 relativePos;
    private final class_2338 worldPos;

    public ServerCubeBlockPileReference(@NotNull CubeBlockPile cubeBlockPile, @NotNull class_2338 relativePos) {
        this.cubeBlockPile = Objects.requireNonNull(cubeBlockPile, "CubeBlockPile cannot be null");
        this.relativePos = Objects.requireNonNull(relativePos, "Relative position cannot be null");
        this.worldPos = cubeBlockPile.getWorldPos(relativePos);

        // 验证相对坐标是否在有效范围内
        validateRelativePosition();
    }

    /**
     * 验证相对坐标是否在方块堆的有效范围内
     */
    private void validateRelativePosition() {
        if (relativePos.method_10263() < 0 || relativePos.method_10263() >= cubeBlockPile.getRange().getWidth() ||
                relativePos.method_10264() < 0 || relativePos.method_10264() >= cubeBlockPile.getRange().getHeight() ||
                relativePos.method_10260() < 0 || relativePos.method_10260() >= cubeBlockPile.getRange().getDepth()) {
            throw new IllegalArgumentException("Relative position " + relativePos +
                    " is out of CubeBlockPile range " + cubeBlockPile.getRange());
        }
    }

    /**
     * 从世界坐标创建服务端引用
     */
    @Nullable
    public static ServerCubeBlockPileReference fromWorldPos(@NotNull CubeBlockPile cubeBlockPile, @NotNull class_2338 worldPos) {
        if (cubeBlockPile.isDisposed()) {
            return null;
        }

        if (!cubeBlockPile.getRange().contains(worldPos)) {
            LOGGER.warn("World position {} is not within CubeBlockPile range {}",
                    worldPos, cubeBlockPile.getRange());
            return null;
        }

        class_2338 masterPos = cubeBlockPile.getMasterPos();
        class_2338 relativePos = new class_2338(
                worldPos.method_10263() - masterPos.method_10263(),
                worldPos.method_10264() - masterPos.method_10264(),
                worldPos.method_10260() - masterPos.method_10260()
        );

        return new ServerCubeBlockPileReference(cubeBlockPile, relativePos);
    }

    /**
     * 从世界坐标创建通用引用（服务端或客户端）
     */
    @Nullable
    public static CubeBlockPileReference fromWorldPos(@NotNull class_4538 world, @NotNull class_2338 worldPos, boolean createClientReference) {
        CubeBlockPile cubeBlockPile = CubeBlockPileManager.findCubeBlockPile(world, worldPos);
        if (cubeBlockPile == null || cubeBlockPile.isDisposed()) {
            return null;
        }

        class_2338 masterPos = cubeBlockPile.getMasterPos();
        class_2338 relativePos = new class_2338(
                worldPos.method_10263() - masterPos.method_10263(),
                worldPos.method_10264() - masterPos.method_10264(),
                worldPos.method_10260() - masterPos.method_10260()
        );

        try {
            if (createClientReference && world.method_8608()) {
                // 在客户端创建客户端引用
                ServerCubeBlockPileReference serverRef = new ServerCubeBlockPileReference(cubeBlockPile, relativePos);
                return ClientCubeBlockPileReference.fromServerReference(serverRef);
            } else {
                // 在服务端创建服务端引用
                return new ServerCubeBlockPileReference(cubeBlockPile, relativePos);
            }
        } catch (IllegalArgumentException e) {
            LOGGER.warn("World position {} is not within CubeBlockPile range", worldPos);
            return null;
        }
    }

    /**
     * 从相对坐标创建引用
     */
    @NotNull
    public static CubeBlockPileReference fromRelativePos(@NotNull CubeBlockPile cubeBlockPile, @NotNull class_2338 relativePos) {
        return new ServerCubeBlockPileReference(cubeBlockPile, relativePos);
    }

    /**
     * 从NBT反序列化引用（服务端版本）
     */
    @Nullable
    public static ServerCubeBlockPileReference fromNbt(@NotNull class_4538 world, @NotNull class_2487 nbt) {
        try {
            // 读取主方块坐标
            class_2338 masterPos = class_2512.method_10691(nbt.method_10562(MASTER_POS_KEY));

            // 读取相对坐标
            class_2338 relativePos = class_2512.method_10691(nbt.method_10562(RELATIVE_POS_KEY));

            // 读取基础方块
            String blockId = nbt.method_10558(BASE_BLOCK_KEY);
            class_2248 baseBlock = net.minecraft.class_7923.field_41175.method_10223(class_2960.method_12829(blockId));

            // 查找对应的CubeBlockPile（服务端引用）
            CubeBlockPile cubeBlockPile = CubeBlockPileManager.findCubeBlockPile(world, masterPos);
            if (cubeBlockPile == null || cubeBlockPile.isDisposed()) {
                LOGGER.warn("CubeBlockPile at {} not found or disposed during deserialization", masterPos);
                return null;
            }

            // 验证基础方块是否匹配
            if (cubeBlockPile.getBaseBlock() != baseBlock) {
                LOGGER.warn("Base block mismatch during deserialization. Expected: {}, Found: {}",
                        baseBlock, cubeBlockPile.getBaseBlock());
                return null;
            }

            // 创建服务端引用
            return new ServerCubeBlockPileReference(cubeBlockPile, relativePos);

        } catch (Exception e) {
            LOGGER.error("Failed to deserialize CubeBlockPileReference from NBT: {}", e.getMessage());
            return null;
        }
    }

    @Override
    @NotNull
    public class_2487 toNbt() {
        class_2487 nbt = new class_2487();

        // 主方块坐标
        nbt.method_10566(MASTER_POS_KEY, class_2512.method_10692(cubeBlockPile.getMasterPos()));

        // 相对坐标
        nbt.method_10566(RELATIVE_POS_KEY, class_2512.method_10692(relativePos));

        // 基础方块
        nbt.method_10582(BASE_BLOCK_KEY, net.minecraft.class_7923.field_41175.method_10221(cubeBlockPile.getBaseBlock()).toString());

        // 结构尺寸
        nbt.method_10569(STRUCTURE_WIDTH_KEY, getStructureWidth());
        nbt.method_10569(STRUCTURE_HEIGHT_KEY, getStructureHeight());
        nbt.method_10569(STRUCTURE_DEPTH_KEY, getStructureDepth());

        return nbt;
    }

    @Override
    public boolean matchesBlock(class_2248 block) {
        if (cubeBlockPile.isDisposed()) {
            LOGGER.warn("Attempted to check block match with disposed CubeBlockPile");
            return false;
        }
        return cubeBlockPile.getBaseBlock() == block;
    }

    @Override
    public boolean matchesBlockState(class_2680 blockState) {
        if (blockState != null) {
            return matchesBlock(blockState.method_26204());
        }
        return false;
    }

    @Override
    public boolean matchesBlockEntity(class_2586 blockEntity) {
        if (blockEntity == null) {
            return false;
        }
        return matchesBlockState(blockEntity.method_11010());
    }

    @Override
    public boolean isMasterBlock() {
        return relativePos.method_10263() == 0 && relativePos.method_10264() == 0 && relativePos.method_10260() == 0;
    }

    @Override
    public @NotNull class_2338 getMasterWorldPos() {
        if (cubeBlockPile.isDisposed()) {
            throw new IllegalStateException("CubeBlockPile has been disposed");
        }
        return cubeBlockPile.getMasterPos();
    }

    @Override
    public @NotNull class_2338 getWorldPos() {
        return worldPos;
    }

    @Override
    public @NotNull class_2338 getRelativePos() {
        return relativePos;
    }

    @Override
    public @NotNull class_2248 getBaseBlock() {
        if (cubeBlockPile.isDisposed()) {
            throw new IllegalStateException("CubeBlockPile has been disposed");
        }
        return cubeBlockPile.getBaseBlock();
    }

    @Override
    public int getVolume() {
        return cubeBlockPile.isDisposed() ? 0 : cubeBlockPile.getVolume();
    }

    @Override
    public boolean containsWorldPos(@NotNull class_2338 worldPos) {
        return !cubeBlockPile.isDisposed() && cubeBlockPile.getRange().contains(worldPos);
    }

    @Override
    public boolean checkIntegrity() {
        if (cubeBlockPile.isDisposed()) {
            LOGGER.warn("Attempted to check integrity of disposed CubeBlockPile");
            return false;
        }
        return cubeBlockPile.checkIntegrity();
    }

    @Override
    public boolean isDisposed() {
        return cubeBlockPile.isDisposed();
    }

    @Override
    public boolean isValid() {
        return !cubeBlockPile.isDisposed() && cubeBlockPile.checkIntegrity();
    }

    @Override
    public void dispose() {
        // 这里只是清理引用，实际的CubeBlockPile由CubeBlockPileManager管理
    }

    @Override
    public int getRelativeX() {
        return relativePos.method_10263();
    }

    @Override
    public int getRelativeY() {
        return relativePos.method_10264();
    }

    @Override
    public int getRelativeZ() {
        return relativePos.method_10260();
    }

    @Override
    public int getStructureWidth() {
        return cubeBlockPile.isDisposed() ? 0 : cubeBlockPile.getRange().getWidth();
    }

    @Override
    public int getStructureHeight() {
        return cubeBlockPile.isDisposed() ? 0 : cubeBlockPile.getRange().getHeight();
    }

    @Override
    public int getStructureDepth() {
        return cubeBlockPile.isDisposed() ? 0 : cubeBlockPile.getRange().getDepth();
    }

    /**
     * 获取方块堆堆实例（仅服务端可用）
     */
    public CubeBlockPile getCubeBlockPile() {
        return cubeBlockPile;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        ServerCubeBlockPileReference that = (ServerCubeBlockPileReference) obj;
        return Objects.equals(cubeBlockPile, that.cubeBlockPile) &&
                Objects.equals(relativePos, that.relativePos);
    }

    @Override
    public int hashCode() {
        return Objects.hash(cubeBlockPile, relativePos);
    }

    @Override
    public String toString() {
        return String.format("ServerCubeBlockPileReference{multiBlock=%s, relativePos=%s, worldPos=%s, isMaster=%b, size=%dx%dx%d}",
                cubeBlockPile.getMasterPos(), relativePos, worldPos, isMasterBlock(),
                getStructureWidth(), getStructureHeight(), getStructureDepth());
    }
}