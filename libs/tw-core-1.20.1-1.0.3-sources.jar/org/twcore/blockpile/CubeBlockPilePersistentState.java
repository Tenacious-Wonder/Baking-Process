package org.twcore.blockpile;

import net.minecraft.class_18;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2507;
import net.minecraft.class_2512;
import net.minecraft.class_2520;
import net.minecraft.class_26;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_5218;
import net.minecraft.nbt.*;
import net.minecraft.server.MinecraftServer;
import org.jetbrains.annotations.NotNull;
import org.slf4j.Logger;
import org.twcore.TWCore;
import org.twcore.api.blockpile.CubeBlockPile;

import java.io.File;
import java.io.IOException;
import java.util.Collection;
import java.util.Collections;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * 方块堆数据的持久化存储
 */
public class CubeBlockPilePersistentState extends class_18 {
    private static final Logger LOGGER = TWCore.LOGGER;
    private static final String PERSISTENT_ID = "cubeBlockPiles";

    /**
     * 临时存储的方块堆数据
     * @see CubeBlockPileManager
     */
    private final Map<class_2960, Map<class_2338, CubeBlockPileData>> worldData = new ConcurrentHashMap<>();

    public CubeBlockPilePersistentState() {
        super();
    }

    /**
     * 方块堆数据的序列化表示
     */
    public record CubeBlockPileData(class_2338 masterPos, String baseBlockId, class_2338 start, int width, int height,
                                    int depth) {
        public @NotNull class_2487 toNbt() {
                class_2487 nbt = new class_2487();
                nbt.method_10566("masterPos", class_2512.method_10692(masterPos));
                nbt.method_10582("baseBlockId", baseBlockId);
                nbt.method_10566("start", class_2512.method_10692(start));
                nbt.method_10569("width", width);
                nbt.method_10569("height", height);
                nbt.method_10569("depth", depth);
                return nbt;
            }

            public static @NotNull CubeBlockPilePersistentState.CubeBlockPileData fromNbt(@NotNull class_2487 nbt) {
                class_2338 masterPos = class_2512.method_10691(nbt.method_10562("masterPos"));
                String baseBlockId = nbt.method_10558("baseBlockId");
                class_2338 start = class_2512.method_10691(nbt.method_10562("start"));
                int width = nbt.method_10550("width");
                int height = nbt.method_10550("height");
                int depth = nbt.method_10550("depth");
                return new CubeBlockPileData(masterPos, baseBlockId, start, width, height, depth);
            }
        }

    /**
     * 添加方块堆数据
     */
    public void addCubeBlockPile(@NotNull class_1937 world, @NotNull CubeBlockPile cubeBlockPile) {
        class_2960 worldId = world.method_27983().method_29177();
        Map<class_2338, CubeBlockPileData> worldMap = worldData
                .computeIfAbsent(worldId, k -> new ConcurrentHashMap<>());

        CubeBlockPileData data = new CubeBlockPileData(
                cubeBlockPile.getMasterPos(),
                cubeBlockPile.getBaseBlock().method_40142().method_40237().method_29177().toString(),
                cubeBlockPile.getRange().getStart(),
                cubeBlockPile.getRange().getWidth(),
                cubeBlockPile.getRange().getHeight(),
                cubeBlockPile.getRange().getDepth()
        );

        worldMap.put(cubeBlockPile.getMasterPos(), data);
        method_80();
    }

    /**
     * 移除方块堆数据
     */
    public void removeCubeBlockPile(@NotNull class_1937 world, class_2338 masterPos) {
        class_2960 worldId = world.method_27983().method_29177();
        Map<class_2338, CubeBlockPileData> worldMap = worldData.get(worldId);
        if (worldMap != null) {
            worldMap.remove(masterPos);
            method_80();
        }
    }

    /**
     * 获取世界中所有的方块堆数据
     */
    public Collection<CubeBlockPileData> getCubeBlockPilesForWorld(@NotNull class_1937 world) {
        class_2960 worldId = world.method_27983().method_29177();
        Map<class_2338, CubeBlockPileData> worldMap = worldData.get(worldId);
        return worldMap != null ? worldMap.values() : Collections.emptyList();
    }

    /**
     * 清除世界中的所有方块堆数据
     */
    public void clearWorldData(@NotNull class_1937 world) {
        class_2960 worldId = world.method_27983().method_29177();
        worldData.remove(worldId);
        method_80();
    }

    @Override
    public class_2487 method_75(class_2487 nbt) {
        class_2499 worldsList = new class_2499();

        for (Map.Entry<class_2960, Map<class_2338, CubeBlockPileData>> worldEntry : worldData.entrySet()) {
            class_2487 worldNbt = new class_2487();
            worldNbt.method_10582("worldId", worldEntry.getKey().toString());

            class_2499 cubeBlockPilesList = new class_2499();
            for (CubeBlockPileData data : worldEntry.getValue().values()) {
                cubeBlockPilesList.add(data.toNbt());
            }

            worldNbt.method_10566("cubeBlockPiles", cubeBlockPilesList);
            worldsList.add(worldNbt);
        }

        nbt.method_10566("worlds", worldsList);

        return nbt;
    }

    /**
     * 从NBT读取数据
     */
    public static @NotNull CubeBlockPilePersistentState fromNbt(class_2487 nbt) {
        CubeBlockPilePersistentState state = new CubeBlockPilePersistentState();

        class_2499 worldsList = nbt.method_10554("worlds", class_2520.field_33260);
        for (class_2520 worldElement : worldsList) {
            class_2487 worldNbt = (class_2487) worldElement;
            class_2960 worldId = new class_2960(worldNbt.method_10558("worldId"));

            Map<class_2338, CubeBlockPileData> worldMap = new ConcurrentHashMap<>();
            class_2499 cubeBlockPilesList = worldNbt.method_10554("cubeBlockPiles", class_2520.field_33260);

            for (class_2520 blockElement : cubeBlockPilesList) {
                class_2487 blockNbt = (class_2487) blockElement;
                try {
                    CubeBlockPileData data = CubeBlockPileData.fromNbt(blockNbt);
                    worldMap.put(data.masterPos, data);
                } catch (Exception e) {
                    LOGGER.error("Failed to load CubeBlockPile data from NBT: {}", e.getMessage());
                }
            }

            state.worldData.put(worldId, worldMap);
        }

        return state;
    }

    /**
     * 获取或创建持久化状态
     */
    public static CubeBlockPilePersistentState getOrCreate(class_3218 world) {
        class_26 persistentStateManager = world.method_17983();
        return persistentStateManager.method_17924(
                CubeBlockPilePersistentState::fromNbt,
                CubeBlockPilePersistentState::new,
                PERSISTENT_ID
        );
    }

    /**
     * 保存到文件（手动备份）
     */
    public void saveToFile(MinecraftServer server) {
        try {
            File worldDir = server.method_27050(class_5218.field_24188).toFile();
            File backupFile = new File(worldDir, "cubeBlockPileblocks_backup.dat");

            class_2487 nbt = this.method_75(new class_2487());
            class_2507.method_10630(nbt, backupFile);
        } catch (IOException e) {
            LOGGER.error("Failed to backup CubeBlockPile data: {}", e.getMessage());
        }
    }
}