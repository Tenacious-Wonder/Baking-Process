package org.twcore.registry;

import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_4176;
import org.twcore.TWCore;
import org.twcore.content.Content;
import org.twcore.content.FoodContent;
import org.twcore.content.HaveColorContent;

public class Contents {
    public static final String SOUP = "soup";
    public static final String BASE_LIQUID = "base_liquid";
    public static final String SYRUP = "syrup";

    // 汤
    public static final Content MUSHROOM_STEW = registerContent("mushroom_stew",
            new FoodContent(SOUP, class_4176.field_18661));

    public static final Content BEETROOT_SOUP = registerContent("beetroot_soup",
            new FoodContent(SOUP, class_4176.field_18642));

    public static final Content RABBIT_STEW = registerContent("rabbit_stew",
            new FoodContent(SOUP, class_4176.field_18631));

    // 基础液体
    public static final Content WATER = registerContent("water",
            new HaveColorContent(BASE_LIQUID, 4159204));

    public static final Content MILK = registerContent("milk",
            new HaveColorContent(BASE_LIQUID, 0xFFFAF2ED));

    // 糖浆
    public static final Content HONEY = registerContent("honey", new Content(SYRUP));

    public static Content registerContent(String name, Content content) {
        return class_2378.method_10230(TWRegistries.CONTENT, new class_2960(TWCore.MOD_ID, name), content);
    }

    public static void registerAll() {}
}
