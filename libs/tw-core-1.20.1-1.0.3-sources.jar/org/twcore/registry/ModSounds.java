package org.twcore.registry;

import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_3414;
import net.minecraft.class_7923;
import org.twcore.TWCore;

public class ModSounds {
    public static final class_3414 SOUP_FILL = registerSoundEvent("soup_fill");

    private static class_3414 registerSoundEvent(String name) {
        class_2960 id = new class_2960(TWCore.MOD_ID, name);
        return class_2378.method_10230(class_7923.field_41172, id, class_3414.method_47908(id));
    }

    public static void registerAll() {}
}
