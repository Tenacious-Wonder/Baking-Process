package org.twcore.registry;

import net.minecraft.class_1802;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_3417;
import org.twcore.TWCore;
import org.twcore.container.*;

public class ContainerTypes {
    // 碗
    public static final ContainerType BOWL = registerContainerType("bowl",
            new BowlContainer(new ContainerType.ContainerSettings(class_1802.field_8428)
                    .setUseSound(ModSounds.SOUP_FILL)));
    // 瓶子
    public static final ContainerType POTION = registerContainerType("potion",
            new PotionContainer(new ContainerType.ContainerSettings(class_1802.field_8469)));
    // 桶
    public static final ContainerType BUCKET = registerContainerType("bucket",
            new BucketContainer(new ContainerType.ContainerSettings(class_1802.field_8550)
                    .setBaseCapacity(3)
                    .setUseSound(class_3417.field_14834)));

    public static ContainerType registerContainerType(String name, ContainerType containerType) {
        return class_2378.method_10230(TWRegistries.CONTAINER_TYPE, new class_2960(TWCore.MOD_ID, name), containerType);
    }

    public static void registerAll() {}

    /**
     * 映射容器注册。
     *
     * @see AbstractMappedContainer
     */
    public static void initDefaultMappings() {
        // 碗映射
        BowlContainer bowl = (BowlContainer) BOWL;
        bowl.registerContentMapping(Contents.MUSHROOM_STEW, class_1802.field_8208);
        bowl.registerContentMapping(Contents.BEETROOT_SOUP, class_1802.field_8515);
        bowl.registerContentMapping(Contents.RABBIT_STEW, class_1802.field_8308);

        // 桶映射
        BucketContainer bucket = (BucketContainer) BUCKET;
        bucket.registerContentMapping(Contents.WATER, class_1802.field_8705);
        bucket.registerContentMapping(Contents.MILK, class_1802.field_8103);

        // 瓶子映射
        PotionContainer potion = (PotionContainer) POTION;
        potion.registerContentMapping(Contents.HONEY, class_1802.field_20417);
    }
}
