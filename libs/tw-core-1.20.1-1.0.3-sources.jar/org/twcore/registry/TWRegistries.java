package org.twcore.registry;

import net.fabricmc.fabric.api.event.registry.FabricRegistryBuilder;
import net.fabricmc.fabric.api.event.registry.RegistryAttribute;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import org.twcore.TWCore;
import org.twcore.container.ContainerType;
import org.twcore.content.Content;

public class TWRegistries {
    public static class_2378<Content> CONTENT = of("content");

    public static class_2378<ContainerType> CONTAINER_TYPE = of("container_type");

    public static <T> class_2378<T> of(String id) {
        class_5321<class_2378<T>> key = class_5321.method_29180(new class_2960(TWCore.MOD_ID, id));

        return FabricRegistryBuilder.createSimple(key)
                .attribute(RegistryAttribute.SYNCED)
                .buildAndRegister();
    }

    public static void registerAll() {}
}
