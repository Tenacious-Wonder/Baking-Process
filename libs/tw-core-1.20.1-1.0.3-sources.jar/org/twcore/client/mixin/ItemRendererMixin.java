package org.twcore.client.mixin;

import net.minecraft.class_1087;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_310;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_763;
import net.minecraft.class_811;
import net.minecraft.class_918;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.twcore.client.api.render.ReplaceItemModel;

@Mixin(class_918.class)
public class ItemRendererMixin {

    @Shadow @Final private class_763 models;
    @Shadow @Final private class_310 client;

    @ModifyVariable(
            method = "renderItem(Lnet/minecraft/item/ItemStack;Lnet/minecraft/client/render/model/json/ModelTransformationMode;ZLnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumerProvider;IILnet/minecraft/client/render/model/BakedModel;)V",
            at = @At("HEAD"),
            argsOnly = true
    )
    private class_1087 renderFlourItem(
            class_1087 originalModel,
            class_1799 stack,
            class_811 renderMode,
            boolean leftHanded,
            class_4587 matrices,
            class_4597 vertexConsumers,
            int light,
            int overlay,
            class_1087 model) {

        if (stack == null || stack.method_7960()) {
            return originalModel;
        }

        // 跳过三叉戟和望远镜的原版特殊处理
        if (stack.method_31574(class_1802.field_8547) || stack.method_31574(class_1802.field_27070)) {
            return originalModel;
        }

        ReplaceItemModel replacer = ReplaceItemModel.getReplace(stack.method_7909());
        if (replacer != null) {
            ReplaceItemModel.ReplaceContext context = new ReplaceItemModel.ReplaceContext(
                    stack,
                    renderMode,
                    leftHanded,
                    originalModel,
                    this.models.method_3303(),
                    this.client.field_1687,
                    matrices,
                    vertexConsumers,
                    light,
                    overlay
            );
            class_1087 replacedModel = replacer.ReplaceModel(context);
            return replacedModel != null ? replacedModel : originalModel;
        }

        return originalModel;
    }
}