package org.twcore.client.api.render;

import net.minecraft.class_2338;
import net.minecraft.class_2586;
import net.minecraft.class_327;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import org.twcore.api.blockpile.CubeBlockPile;
import org.twcore.api.blockpile.CubeBlockPileReference;

/**
 * 对应用了{@link CubeBlockPile}的方块添加显示方块堆信息的效果
 * <p>该渲染类会在方块的上方渲染出方块堆的信息便于调试</p>
 * @param <T> 对应的方块实体
 */
public interface CubeBlockPileDebugRenderer<T extends class_2586> {

    /**
     * 获取用于渲染的文本渲染器。
     *
     * @return 文本渲染器
     */
    class_327 getTextRenderer();

    /**
     * 获取方块的多方块引用
     * @param entity 对应的方块实体
     */
    CubeBlockPileReference getReference(T entity);

    /**
     * 进行其他的调试渲染
     * @param entity 对应的方块实体
     * @param reference 对应的多方块引用
     * @param matrices 变换矩阵，注意，此时的矩阵已经被变换到了渲染文字的地方。
     *                 如果需要一个新的矩阵，请再对矩阵进行一次推送
     */
    default void otherDebugRender(T entity, CubeBlockPileReference reference, float tickDelta, class_4587 matrices, class_4597 vertexConsumers, int light, int overlay) {}

    /**
     * 渲染多方块调试信息。
     */
    default void renderDebugInfo(T entity, float tickDelta, class_4587 matrices, class_4597 vertexConsumers, int light, int overlay) {
        // 获取多方块引用
        CubeBlockPileReference multiBlockRef = getReference(entity);
        if (multiBlockRef == null || multiBlockRef.isDisposed()) {
            return;
        }

        // 获取坐标信息
        class_2338 masterPos = multiBlockRef.getMasterWorldPos();
        class_2338 relativePos = multiBlockRef.getRelativePos();
        class_2338 currentPos = entity.method_11016();

        // 构建显示的文本
        String masterText = String.format("%d,%d,%d", masterPos.method_10263(), masterPos.method_10264(), masterPos.method_10260());
        String relativeText = String.format("%d,%d,%d", relativePos.method_10263(), relativePos.method_10264(), relativePos.method_10260());
        String currentText = String.format("%d,%d,%d", currentPos.method_10263(), currentPos.method_10264(), currentPos.method_10260());

        // 检查是否为master方块
        boolean isMaster = multiBlockRef.isMasterBlock();
        String masterStatus = isMaster ? "MASTER" : "SLAVE";

        // 检查方块堆完整性
        boolean isIntact = multiBlockRef.checkIntegrity();
        String integrityStatus = isIntact ? "INTACT" : "BROKEN";

        matrices.method_22903();

        try {
            // 将坐标系移动到方块中心上方
            matrices.method_22904(0.5, 1.2, 0.5);

            // 缩放文本，使其不会太大
            float scale = 0.02F;
            matrices.method_22905(scale, -scale, scale);

            // 渲染文本
            int white = 0xFFFFFFFF;  // 添加Alpha通道
            int green = 0xFF00FF00;
            int red = 0xFFFF0000;
            int yellow = 0xFFFFFF00;
            int blue = 0xFF0088FF;

            // 计算文本宽度用于居中
            int masterWidth = getTextRenderer().method_1727(masterText);
            int relativeWidth = getTextRenderer().method_1727(relativeText);
            int currentWidth = getTextRenderer().method_1727(currentText);
            int statusWidth = getTextRenderer().method_1727(masterStatus);
            int integrityWidth = getTextRenderer().method_1727(integrityStatus);

            int maxWidth = Math.max(Math.max(masterWidth, relativeWidth),
                    Math.max(currentWidth, Math.max(statusWidth, integrityWidth)));

            // 获取位置矩阵
            var positionMatrix = matrices.method_23760().method_23761();

            // 渲染主方块坐标（蓝色）
            getTextRenderer().method_27521(
                    masterText,
                    -masterWidth / 2f, -40,
                    blue,
                    false,
                    positionMatrix,
                    vertexConsumers,
                    class_327.class_6415.field_33995,
                    0,
                    light
            );

            // 渲染相对坐标（黄色）
            getTextRenderer().method_27521(
                    relativeText,
                    -relativeWidth / 2f, -30,
                    yellow,
                    false,
                    positionMatrix,
                    vertexConsumers,
                    class_327.class_6415.field_33995,
                    1,
                    light
            );

            // 渲染当前坐标（白色）
            getTextRenderer().method_27521(
                    currentText,
                    -currentWidth / 2f, -20,
                    white,
                    false,
                    positionMatrix,
                    vertexConsumers,
                    class_327.class_6415.field_33995,
                    0,
                    light
            );

            // 渲染主方块状态（绿色表示主方块，白色表示从方块）
            int masterColor = isMaster ? green : white;
            getTextRenderer().method_27521(
                    masterStatus,
                    -statusWidth / 2f, -10,
                    masterColor,
                    false,
                    positionMatrix,
                    vertexConsumers,
                    class_327.class_6415.field_33995,
                    0,
                    light
            );

            // 渲染完整性状态（绿色表示完整，红色表示损坏）
            int integrityColor = isIntact ? green : red;
            getTextRenderer().method_27521(
                    integrityStatus,
                    -integrityWidth / 2f, 0,
                    integrityColor,
                    false,
                    positionMatrix,
                    vertexConsumers,
                    class_327.class_6415.field_33995,
                    0,
                    light
            );

            otherDebugRender(entity, multiBlockRef, tickDelta, matrices, vertexConsumers, light, overlay);
        } finally {
            matrices.method_22909();
        }
    }
}
