package org.twcore.client.api.render;

import org.jetbrains.annotations.Nullable;

import java.util.HashMap;
import java.util.Map;
import java.util.function.Function;
import net.minecraft.class_1087;
import net.minecraft.class_1091;
import net.minecraft.class_1092;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2960;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_638;
import net.minecraft.class_811;

@FunctionalInterface
public interface ReplaceItemModel {
    Map<class_1792, ReplaceItemModel> REPLACE = new HashMap<>();

    /**
     * 注册物品模型替换器
     * @param item 要替换模型的物品
     * @param replace 替换逻辑
     */
    static void registry(class_1792 item, ReplaceItemModel replace) {
        REPLACE.put(item, replace);
    }

    /**
     * 获取物品的模型替换器
     * @param item 物品
     * @return 对应的替换器，如果没有则返回null
     */
    @Nullable
    static ReplaceItemModel getReplace(class_1792 item) {
        return REPLACE.get(item);
    }

    /**
     * 检查物品是否有模型替换器
     * @param item 物品
     * @return 是否有替换器
     */
    static boolean hasReplace(class_1792 item) {
        return REPLACE.containsKey(item);
    }

    /**
     * 清除所有注册的模型替换器
     */
    static void clearAll() {
        REPLACE.clear();
    }

    /**
     * 移除指定物品的模型替换器
     * @param item 物品
     */
    static void remove(class_1792 item) {
        REPLACE.remove(item);
    }

    /**
     * 创建简单的模型替换器，通过模型ID替换
     * @param modelId 新的模型ID
     * @return 替换器函数
     */
    static ReplaceItemModel createSimpleReplacer(class_2960 modelId) {
        return context -> {
            class_1092 modelManager = context.modelManager();
            if (modelManager != null) {
                class_1087 newModel = modelManager.method_4742(
                        class_1091.method_45910(
                                modelId.method_12832(), "inventory"
                        )
                );
                return newModel != null ? newModel : context.originalModel();
            }
            return context.originalModel();
        };
    }

    /**
     * 创建条件模型替换器，根据不同渲染模式使用不同模型
     * @param modeMapper 根据渲染模式返回模型ID的函数
     * @return 替换器函数
     */
    static ReplaceItemModel createConditionalReplacer(
            Function<class_811, class_2960> modeMapper) {
        return context -> {
            class_2960 modelId = modeMapper.apply(context.renderMode());
            if (modelId != null) {
                class_1092 modelManager = context.modelManager();
                if (modelManager != null) {
                    class_1087 newModel = modelManager.method_4742(
                            class_1091.method_45910(
                                    modelId.method_12832(), "inventory"
                            )
                    );
                    if (newModel != null) {
                        return newModel;
                    }
                }
            }
            return context.originalModel();
        };
    }

    /**
     * 替换模型的接口方法
     * @param context 替换上下文
     * @return 替换后的烘焙模型，返回null将使用原始模型
     */
    class_1087 ReplaceModel(ReplaceContext context);

    /**
     * 替换上下文类，包含替换模型所需的所有信息
     */
    record ReplaceContext(class_1799 stack, class_811 renderMode, boolean leftHanded,
                          class_1087 originalModel, class_1092 modelManager, class_1937 world, class_4587 matrices,
                          class_4597 vertexConsumers, int light, int overlay) {

        public class_638 getClientWorld() {
            return world instanceof class_638 ? (class_638) world : null;
        }

        /**
         * 判断是否在GUI中渲染
         */
        public boolean isGuiRender() {
            return renderMode == class_811.field_4317;
        }

        /**
         * 判断是否在第一人称手中渲染
         */
        public boolean isFirstPersonRender() {
            return renderMode.method_29998();
        }

        /**
         * 判断是否在第三人称手中渲染
         */
        public boolean isThirdPersonRender() {
            return renderMode == class_811.field_4323 ||
                    renderMode == class_811.field_4320;
        }

        /**
         * 判断是否在地面渲染
         */
        public boolean isGroundRender() {
            return renderMode == class_811.field_4318;
        }

        /**
         * 判断是否在固定位置渲染（如展示框）
         */
        public boolean isFixedRender() {
            return renderMode == class_811.field_4319;
        }

        /**
         * 判断是否在头部渲染（如头盔）
         */
        public boolean isHeadRender() {
            return renderMode == class_811.field_4316;
        }
    }
}