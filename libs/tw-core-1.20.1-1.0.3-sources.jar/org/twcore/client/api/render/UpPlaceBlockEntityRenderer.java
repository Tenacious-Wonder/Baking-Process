package org.twcore.client.api.render;

import net.minecraft.class_1799;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_5614;
import net.minecraft.class_827;
import org.twcore.api.block.UpPlaceBlock;
import org.twcore.api.block.UpPlaceBlockEntity;

/**
 * 用于渲染放置在{@link UpPlaceBlock}中的内容的渲染器。
 * @param <T> 对应的{@link UpPlaceBlock}的子类
 */
public abstract class UpPlaceBlockEntityRenderer<T extends UpPlaceBlockEntity> implements class_827<T> {
    protected final class_5614.class_5615 context;

    public UpPlaceBlockEntityRenderer(class_5614.class_5615 ctx) {
        this.context = ctx;
    }

    /**
     * 渲染一个摆放在该方块中的物品堆栈。
     *
     * @param stack 要渲染的物品堆栈
     * @param entity 当前的方块实体
     * @apiNote 需要子类在render方法中主动调用该方法渲染
     */
    protected void fromStackRender(class_1799 stack, T entity, float tickDelta, class_4587 matrices,
                                   class_4597 vertexConsumers, int light, int overlay) {
        // 获取渲染器
        UpPlaceStackRenderer renderer = UpPlaceStackRenderer.get(stack.method_7909());

        // 构建渲染上下文
        UpPlaceStackRenderer.RenderContext renderContext = new UpPlaceStackRenderer.RenderContext(
                stack, entity,
                context, tickDelta,
                matrices, vertexConsumers,
                light, overlay);

        // 使用渲染器渲染物品堆栈
        renderer.fromStackRender(renderContext);
    }
}
