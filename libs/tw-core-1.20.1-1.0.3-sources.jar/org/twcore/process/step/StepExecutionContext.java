package org.twcore.process.step;

import org.twcore.api.process.AbstractProcess;
import org.twcore.api.sound.Item2BlockSounds;

import java.util.Random;
import net.minecraft.class_1268;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2392;
import net.minecraft.class_2398;
import net.minecraft.class_2498;
import net.minecraft.class_2680;
import net.minecraft.class_3414;
import net.minecraft.class_3419;
import net.minecraft.class_3965;

/**
 * 步骤执行上下文，封装了执行步骤所需的所有信息。
 *
 * <p>当步骤执行时，流程系统会创建一个上下文对象并传递给步骤的{@link Step#execute}方法。
 * 上下文包含：</p>
 * <ul>
 *   <li>流程实例：可以访问流程状态数据</li>
 *   <li>方块实体、状态、位置和世界</li>
 *   <li>玩家信息和交互信息</li>
 *   <li>临时上下文数据存储（仅当前步骤执行期间有效）</li>
 * </ul>
 *
 * <p>使用上下文对象，步骤可以：</p>
 * <ul>
 *   <li>访问和修改流程状态数据</li>
 *   <li>操作方块实体和方块状态</li>
 *   <li>与玩家交互（给予物品、播放音效等）</li>
 *   <li>在步骤执行期间存储临时数据</li>
 * </ul>
 *
 * @param <T>         方块实体类型
 * @param process     当前执行的流程实例
 * @param blockEntity 执行步骤的方块实体
 * @param blockState  方块的当前状态
 * @param world       方块所在的世界
 * @param pos         方块的位置
 * @param player      执行交互的玩家
 * @param hand        玩家使用的手（主手或副手）
 * @param hit         方块点击信息
 */
public record StepExecutionContext<T>(AbstractProcess<T> process, T blockEntity, class_2680 blockState, class_1937 world,
                                      class_2338 pos, class_1657 player, class_1268 hand, class_3965 hit) {

    /**
     * 检查该上下文是否无玩家参与。
     *
     * @return 如果无玩家参与则返回true
     */
    public boolean isNoPlayer() {
        return player == null || hand == null || hit == null;
    }

    /**
     * 获取玩家当前手持的物品堆栈。
     *
     * <p>这是{@code player.getStackInHand(hand)}的快捷方式。</p>
     *
     * @return 玩家手持的物品堆栈
     */
    public class_1799 getHeldItemStack() {
        return player.method_5998(hand);
    }

    /**
     * 检查交互的玩家是否为创造模式。
     *
     * @return 玩家是否为创造模式
     */
    public boolean isCreateMode() {
        return player.method_7337();
    }

    /**
     * 将物品堆栈给予给玩家。
     *
     * @param stack 要给予的物品
     */
    public void giveStack(class_1799 stack) {
        if (!player.method_7270(stack)) {
            player.method_7328(stack, false);
        }
    }

    /**
     * 检查步骤执行是否在客户端。
     *
     * <p>这是{@code world.isClient}的快捷方式。</p>
     *
     * @return 如果在客户端执行，则返回true
     */
    public boolean isClientSide() {
        return world.field_9236;
    }

    /**
     * 检查步骤执行是否在服务器端。
     *
     * <p>这是{@code !world.isClient}的快捷方式。</p>
     *
     * @return 如果在服务器端执行，则返回true
     */
    public boolean isServerSide() {
        return !world.field_9236;
    }

    /**
     * 获取玩家当前手持物品的方块音效组。
     * @return 获取的音效组，物品无法解析时返回石头音效组
     */
    public class_2498 getItemSounds() {
        return Item2BlockSounds.getSoundGroup(getHeldItemStack());
    }

    /**
     * 在方块的位置播放一段声音。
     *
     * @param event 播放的声音事件
     */
    public void playSound(class_3414 event) {
        world.method_8396(
                null,
                pos,
                event,
                class_3419.field_15245,
                0.5F,
                1.0F
        );
    }

    /**
     * 在方块位置生成物品粒子效果。
     *
     * @param stack 用于粒子效果的物品堆栈
     */
    public void spawnItemParticles(class_1799 stack) {
        Random random = new Random();
        double x = pos.method_10263() + 0.5;
        double y = pos.method_10264() + 0.05;
        double z = pos.method_10260() + 0.5;

        int particles = 8;

        for (int i = 0; i < particles; i++) {
            double vx = (random.nextDouble() - 0.5) * 0.4;
            double vy = random.nextDouble() * 0.3;
            double vz = (random.nextDouble() - 0.5) * 0.4;

            world.method_8406(
                    new class_2392(class_2398.field_11218, stack),
                    x, y, z, vx, vy, vz
            );
        }
    }
}