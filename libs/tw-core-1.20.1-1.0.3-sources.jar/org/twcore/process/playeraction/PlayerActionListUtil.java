package org.twcore.process.playeraction;

import org.twcore.TWCore;
import org.twcore.api.process.PlayerAction;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_1799;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2520;

/**
 * 玩家操作列表工具类，用于序列化和反序列化操作列表。
 */
public class PlayerActionListUtil {

    private static final String ACTIONS_KEY = "Actions";
    private static final String ACTION_STRING_KEY = "ActionStr";

    /**
     * 将操作列表写入NBT。
     */
    public static void writeActionsToNbt(class_2487 nbt, List<PlayerAction> actions) {
        class_2499 actionsList = new class_2499();

        for (PlayerAction action : actions) {
            class_2487 actionNbt = new class_2487();
            actionNbt.method_10582(ACTION_STRING_KEY, action.toString());
            actionsList.add(actionNbt);
        }

        nbt.method_10566(ACTIONS_KEY, actionsList);
    }

    /**
     * 从NBT读取操作列表。
     */
    public static List<PlayerAction> readActionsFromNbt(class_2487 nbt) {
        List<PlayerAction> actions = new ArrayList<>();

        if (nbt.method_10573(ACTIONS_KEY, class_2520.field_33259)) {
            class_2499 actionsList = nbt.method_10554(ACTIONS_KEY, class_2520.field_33260);

            for (int i = 0; i < actionsList.size(); i++) {
                class_2487 actionNbt = actionsList.method_10602(i);
                String actionStr = actionNbt.method_10558(ACTION_STRING_KEY);

                try {
                    PlayerAction action = PlayerAction.fromString(actionStr);
                    actions.add(action);
                } catch (Exception e) {
                    // 记录错误但继续处理其他操作
                    TWCore.LOGGER.warn("Unable to resolve the operation string: {}", actionStr, e);
                }
            }
        }

        return actions;
    }

    /**
     * 将操作列表转换为物品堆栈列表（用于库存接口兼容）。
     */
    public static List<class_1799> actionsToItemStacks(List<PlayerAction> actions) {
        List<class_1799> stacks = new ArrayList<>();

        for (PlayerAction action : actions) {
            stacks.add(action.toItemStack());
        }

        return stacks;
    }
}