package org.twcore.process.playeraction.impl;

import org.twcore.api.process.PlayerAction;
import org.twcore.process.step.StepExecutionContext;

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_7923;

/**
 * 添加物品操作。
 *
 * <p>这是原物品系统的直接对应。</p>
 */
public class AddItemPlayerAction extends PlayerAction {
    public static final String TYPE = "add_item";
    /** 物品路径编码重映射，用于解决编码冲突 */
    public static final Map<class_1792, String> REMAPPING = new HashMap<>();

    private final class_1792 item;
    private final int count;

    /**
     * 从字符串参数创建添加物品操作。
     *
     * @param params 参数字符串数组
     * @return 添加物品操作实例
     */
    public static AddItemPlayerAction fromParams(String[] params) {
        if (params.length < 1) {
            throw new IllegalArgumentException("The Add Item parameter requires the Item ID parameter");
        }

        class_2960 itemId = class_2960.method_12829(params[0]);
        if (itemId == null) {
            throw new IllegalArgumentException("Invalid item ID: " + params[0]);
        }

        class_1792 item = class_7923.field_41178.method_10223(itemId);
        if (item == class_1802.field_8162) {
            throw new IllegalArgumentException("No item found: " + itemId);
        }

        int count = 1;
        if (params.length >= 2) {
            try {
                count = Integer.parseInt(params[1]);
                if (count <= 0) {
                    throw new IllegalArgumentException("The quantity must be greater than 0: " + count);
                }
            } catch (NumberFormatException e) {
                throw new IllegalArgumentException("Invalid quantity: " + params[1]);
            }
        }

        return new AddItemPlayerAction(item, count);
    }

    /**
     * 从上下文创建添加物品操作。
     *
     * @param context 步骤执行上下文
     * @return 如果玩家手持物品，则返回对应的添加物品操作
     */
    public static Optional<PlayerAction> fromContext(StepExecutionContext<?> context) {
        class_1799 heldItem = context.getHeldItemStack();
        if (!heldItem.method_7960()) {
            return Optional.of(new AddItemPlayerAction(heldItem.method_7909(), 1));
        }
        return Optional.empty();
    }

    /**
     * 创建添加物品操作。
     *
     * @param item 要添加的物品
     * @param count 物品数量（默认为1）
     */
    public AddItemPlayerAction(class_1792 item, int count) {
        if (item == null) {
            throw new IllegalArgumentException("Items cannot be null");
        }
        if (count <= 0) {
            throw new IllegalArgumentException("The quantity must be greater than 0");
        }

        this.item = item;
        this.count = count;
    }

    public AddItemPlayerAction(class_1792 item) {
        this(item, 1);
    }

    @Override
    public String toString() {
        class_2960 itemId = class_7923.field_41178.method_10221(item);
        return String.format("add_item|%s|%d", itemId, count);
    }

    @Override
    public class_1799 toItemStack() {
        return new class_1799(item, count);
    }

    @Override
    public void consume(StepExecutionContext<?> context) {
        // 如果不是创造模式，消耗玩家手持物品
        if (!context.isCreateMode()) {
            class_1799 heldItem = context.getHeldItemStack();
            if (!heldItem.method_7960() && heldItem.method_31574(item)) {
                heldItem.method_7934(count);
            }
        }

        // 播放操作音效
        context.playSound(context.getItemSounds().method_10598());
    }

    @Override
    public boolean matches(PlayerAction other) {
        if (!(other instanceof AddItemPlayerAction otherAction)) {
            return false;
        }

        // 匹配物品类型和数量
        return this.item == otherAction.item && count == otherAction.count;
    }

    /**
     * 编码格式: i[命名空间前2位]_[物品路径前3位][数量，如果为1则省略]。
     * @return 简短编码
     */
    @Override
    public String getCode() {
        class_2960 itemId = class_7923.field_41178.method_10221(item);

        // 1. 操作类型固定位: "i" 表示添加物品
        StringBuilder code = new StringBuilder("i");

        // 2. 命名空间前2位（不足补'_'）
        String namespace = itemId.method_12836();
        if (namespace.length() >= 2) {
            code.append(namespace, 0, 2);
        } else {
            code.append(namespace).append("_".repeat(2 - namespace.length()));
        }

        code.append("_");

        // 3. 物品路径前3位（不足补'_'）
        String path = itemId.method_12832();
        if (REMAPPING.containsKey(item)) {
            code.append(REMAPPING.get(item));
        } else if (path.length() >= 3) {
            code.append(path, 0, 3);
        } else {
            code.append(path).append("_".repeat(3 - path.length()));
        }

        // 4. 数量（如果大于1则添加，否则省略）
        if (count > 1) {
            code.append(count);
        }

        return code.toString();
    }

    @Override
    public class_2561 getDisplayName() {
        return class_2561.method_43469("player_action.add_item", item.method_7848(), count);
    }

    @Override
    public String getType() {
        return TYPE;
    }

    public class_1792 getItem() {
        return item;
    }

    public int getCount() {
        return count;
    }
}