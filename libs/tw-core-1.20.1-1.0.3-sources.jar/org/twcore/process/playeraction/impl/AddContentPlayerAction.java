package org.twcore.process.playeraction.impl;

import org.twcore.api.content.ContainerStack;
import org.twcore.api.content.ContainerUtil;
import org.twcore.container.ContainerType;
import org.twcore.content.Content;
import org.twcore.api.process.PlayerAction;
import org.twcore.process.step.StepExecutionContext;
import org.twcore.registry.TWRegistries;

import java.util.Optional;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_2960;

/**
 * 添加内容物操作。
 * <p>
 * 用于在流程中要求玩家消耗一个装有特定内容物的容器物品（如一碗水、一瓶牛奶）。
 * 支持从字符串参数创建，或从玩家手持物品的上下文中自动识别。
 * </p>
 */
public class AddContentPlayerAction extends PlayerAction {
    public static final String TYPE = "add_content";

    private final Content content;
    private final int count;

    /**
     * 从字符串参数创建添加内容物操作。
     *
     * @param params 参数字符串数组，第一个元素为内容物的注册表ID，第二个可选元素为所需数量（默认1）
     * @return 添加内容物操作实例
     * @throws IllegalArgumentException 如果参数无效或内容物未注册
     */
    public static AddContentPlayerAction fromParams(String[] params) {
        if (params.length < 1) {
            throw new IllegalArgumentException("The Add Content parameter requires the Content ID parameter");
        }

        class_2960 contentId = class_2960.method_12829(params[0]);
        if (contentId == null) {
            throw new IllegalArgumentException("Invalid Content ID: " + params[0]);
        }

        Content content = TWRegistries.CONTENT.method_10223(contentId);
        if (content == null) {
            throw new IllegalArgumentException("No Content found: " + contentId);
        }

        int count = 1;
        if (params.length >= 2) {
            try {
                count = Integer.parseInt(params[1]);
                if (count <= 0) {
                    throw new IllegalArgumentException("The quantity must be greater than 0: " + count);
                }
            } catch (NumberFormatException e) {
                throw new IllegalArgumentException("Invalid quantity: " + params[1]);
            }
        }

        return new AddContentPlayerAction(content, count);
    }

    /**
     * 从执行上下文创建添加内容物操作。
     * <p>
     * 检查玩家手持物品是否为装有内容物的容器，若是，则以该内容物和容器的基础容量构造操作。
     * </p>
     *
     * @param context 步骤执行上下文
     * @return 如果手持正确的非空容器，则返回对应的操作实例，否则返回空
     */
    public static Optional<PlayerAction> fromContext(StepExecutionContext<?> context) {
        class_1799 heldItem = context.getHeldItemStack();
        Optional<ContainerStack> binding = ContainerUtil.analyze(heldItem);

        if (binding.isPresent()) {
            ContainerStack cs = binding.get();
            if (!cs.isEmpty()) {
                return Optional.of(new AddContentPlayerAction(cs.content(), cs.container().getBaseCapacity()));
            }
        }
        return Optional.empty();
    }

    public AddContentPlayerAction(Content content, int count) {
        if (count <= 0) {
            throw new IllegalArgumentException("The quantity must be greater than 0");
        }
        this.content = content;
        this.count = count;
    }

    public AddContentPlayerAction(Content content) {
        this(content, 1);
    }

    @Override
    public String toString() {
        class_2960 contentId = TWRegistries.CONTENT.method_10221(content);
        return String.format("add_content|%s|%d", contentId, count);
    }

    @Override
    public class_1799 toItemStack() {
        return class_1799.field_8037;
    }

    @Override
    public void consume(StepExecutionContext<?> context) {
        // 播放操作音效
        context.playSound(context.getItemSounds().method_10598());

        if (context.isCreateMode()) {
            return;
        }

        // 如果不是创造模式，消耗玩家手持物品
        class_1799 heldItem = context.getHeldItemStack();
        Optional<ContainerStack> binding = ContainerUtil.analyze(heldItem);

        if (!heldItem.method_7960() && binding.isPresent()) {
            ContainerStack cs = binding.get();
            if (cs.isEmpty()) return; // 空容器无需处理

            ContainerType container = cs.container();
            int capacity = container.getBaseCapacity();

            // 计算需要消耗多少个容器（向上取整）
            int containersNeeded = (int) Math.ceil((double) count / capacity);

            // 消耗对应数量的容器物品
            heldItem.method_7934(containersNeeded);

            // 创建被消耗容器的一个副本，并清空其内容物后返还给玩家
            class_1799 consumedCopy = cs.originalStack().method_46651(containersNeeded);
            class_1799 emptyRemainder = container.replaceContent(consumedCopy, null);
            context.giveStack(emptyRemainder);
        }
    }

    @Override
    public boolean matches(PlayerAction other) {
        if (!(other instanceof AddContentPlayerAction otherAction)) {
            return false;
        }

        // 匹配内容物类型和数量
        return this.content == otherAction.content && this.count <= otherAction.count;
    }

    @Override
    public String getCode() {
        class_2960 contentId = TWRegistries.CONTENT.method_10221(content);
        // 1. 操作类型固定位: "c" 表示添加物品
        StringBuilder code = new StringBuilder("c");

        // 2. 命名空间前2位（不足补'_'）
        if (contentId != null) {
            String namespace = contentId.method_12836();
            if (namespace.length() >= 2) {
                code.append(namespace, 0, 2);
            } else {
                code.append(namespace).append("_".repeat(2 - namespace.length()));
            }
        }

        code.append("_");

        // 3. 物品路径前3位（不足补'_'）
        if (contentId != null) {
            String path = contentId.method_12832();
            if (path.length() >= 3) {
                code.append(path, 0, 3);
            } else {
                code.append(path).append("_".repeat(3 - path.length()));
            }
        }

        // 4. 数量（如果大于1则添加，否则省略）
        if (count > 1) {
            code.append(count);
        }

        return code.toString();
    }

    @Override
    public class_2561 getDisplayName() {
        return class_2561.method_43469("player_action.add_content", content.getDisplayName(), count);
    }

    @Override
    public String getType() {
        return TYPE;
    }

    /**
     * 返回该操作要求的内容物。
     *
     * <p>修复：此前本操作未暴露内部字段访问器，外部只能解析 {@link #toString()} 获取内容物，
     * 现与 {@link AddItemPlayerAction} 对齐提供访问器。</p>
     *
     * @return 内容物
     * @since 1.0.3
     */
    public Content getContent() {
        return content;
    }

    /**
     * 返回该操作要求的内容物数量。
     *
     * @return 内容物数量
     * @since 1.0.3
     */
    public int getCount() {
        return count;
    }
}