package org.twcore.api.block;

import net.minecraft.class_1268;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2680;

/**
 * 标记方块可响应玩家的“轻击”操作（快速左键点击）。
 *
 * <p>当玩家在极短时间内（不超过 5 个游戏 tick）完成一次完整的左键破坏动作时，
 * 实现此接口的方块会触发 {@link #onClickBlock} 回调。
 * 该机制通常用于实现类似“右键点击”的快速交互效果，但使用左键触发，例如：
 * <ul>
 *     <li>自定义工具的特殊功能（敲击、切换模式等）</li>
 *     <li>方块自身的快捷交互（如按钮、开关的快速激活）</li>
 *     <li>调试或辅助类模组中的点击检测</li>
 * </ul>
 *
 * <p>注意：此回调仅当破坏动作在 5 tick 内完成时才会触发。
 * 实际时长取决于网络延迟和游戏刻计算，建议避免依赖精确的时间阈值。
 * 该方法仅在服务端调用，客户端不会收到通知。
 *
 * @see #onClickBlock(class_2680, class_1937, class_2338, class_1657, class_1268, class_2350)
 */
public interface HaveClickInteractBlock {
    /**
     * 当玩家左键轻击方块时调用(破坏时间<=5tick)。
     * <p>此方法只会在服务端调用。</p>
     *
     * @param state     方块状态
     * @param world     世界
     * @param pos       方块坐标
     * @param player    点击方块的玩家
     * @param hand      使用的手(破坏时为主手)
     * @param direction 破坏方向
     */
    void onClickBlock(class_2680 state, class_1937 world, class_2338 pos, class_1657 player, class_1268 hand, class_2350 direction);
}
