package org.twcore.api.block;

import net.minecraft.class_1263;
import net.minecraft.class_1264;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1922;
import net.minecraft.class_1937;
import net.minecraft.class_2237;
import net.minecraft.class_2338;
import net.minecraft.class_2586;
import net.minecraft.class_259;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_3414;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3726;
import net.minecraft.class_3965;

/**
 * 可放置物品的方块基类，提供统一的物品放置和取出交互机制。
 * <p>
 * 该方块通过与实现{@link class_1263}接口的方块实体配合，允许玩家在方块上放置和取出物品。
 * 支持自定义放置和取出条件、音效以及物品的视觉表现。
 * </p>
 *
 * @see UpPlaceBlockEntity
 */
public abstract class UpPlaceBlock extends class_2237 {
    /**
     * 方块交互音效配置
     */
    public final UpSounds upSounds;

    public UpPlaceBlock(class_2251 settings, UpSounds upSounds) {
        super(settings);
        this.upSounds = upSounds;
    }

    public UpPlaceBlock(class_2251 settings) {
        this(settings, UpSounds.DYNAMIC);
    }

    /**
     * 当方块被替换或破坏时，将方块实体中的库存物品掉落出来
     * <p>
     * 确保方块被破坏时不会丢失其中的物品。
     * </p>
     */
    @Override
    public void method_9536(class_2680 state, class_1937 world, class_2338 pos, class_2680 newState, boolean moved) {
        if (!state.method_27852(newState.method_26204())) {
            class_2586 blockEntity = world.method_8321(pos);
            if (blockEntity instanceof class_1263 inventory) {
                class_1264.method_5451(world, pos, inventory);
                world.method_8455(pos, this);
            }
            super.method_9536(state, world, pos, newState, moved);
        }
    }

    /**
     * 获取方块的轮廓形状，合并基础形状与容器中物品的形状
     * <p>
     * 当方块实体中有物品时，轮廓形状会是基础形状和物品形状的并集，
     * 这样可以正确显示物品在方块上的视觉表现。
     * </p>
     */
    @Override
    public class_265 method_9530(class_2680 state, class_1922 world, class_2338 pos, class_3726 context) {
        class_2586 entity = world.method_8321(pos);
        if (entity instanceof UpPlaceBlockEntity blockEntity && !blockEntity.method_5442()) {
            return class_259.method_1084(
                    getBaseShape(state, world, pos, context),
                    blockEntity.getContentShape(state, world, pos, context)
            );
        }
        return getBaseShape(state, world, pos, context);
    }

    /**
     * 获取方块的基准轮廓形状
     * <p>
     * 子类必须实现此方法来定义方块本身的基本碰撞体积。
     * </p>
     *
     * @param state 当前方块状态
     * @param world 方块所在的世界
     * @param pos 方块位置
     * @param context 形状计算上下文
     * @return 方块的基准轮廓形状
     */
    public abstract class_265 getBaseShape(class_2680 state, class_1922 world, class_2338 pos, class_3726 context);

    @Override
    public class_1269 method_9534(class_2680 state, class_1937 world, class_2338 pos, class_1657 player, class_1268 hand, class_3965 hit) {
        class_1799 handStack = player.method_5998(hand);
        class_2586 blockEntity = world.method_8321(pos);

        if (blockEntity instanceof UpPlaceBlockEntity upPlaceBlockEntity) {
            // 尝试取出物品
            if (canFetched(upPlaceBlockEntity, handStack)) {
                UpPlaceBlockEntity.Result fetchResult = upPlaceBlockEntity.tryFetchItem(player, hit);
                if (fetchResult.isAccepted()) {
                    upPlaceBlockEntity.onFetch(state, world, pos, player, hand, hit, fetchResult.opsStacks());
                    return fetchResult.result();
                }
            }

            // 尝试放置物品
            if (canPlace(upPlaceBlockEntity, handStack)) {
                UpPlaceBlockEntity.Result placeResult = upPlaceBlockEntity.tryAddItem(handStack, hit);
                if (placeResult.isAccepted()) {
                    upPlaceBlockEntity.onPlace(state, world, pos, player, hand, hit, handStack, placeResult.opsStacks());
                    return placeResult.result();
                }
            }
        }

        return class_1269.field_5814;
    }

    /**
     * 检查当前条件下是否可以执行取出操作
     * <p>
     * 子类必须实现此方法来确定取出操作的触发条件，
     * 例如：手中是否持有特定工具、方块中是否有物品等。
     * </p>
     *
     * @param blockEntity 目标方块实体
     * @param handStack 玩家手中的物品堆栈
     * @return 如果可以取出物品返回true，否则返回false
     */
    public abstract boolean canFetched(UpPlaceBlockEntity blockEntity, class_1799 handStack);

    /**
     * 检查当前条件下是否可以执行放置操作
     * <p>
     * 子类必须实现此方法来确定放置操作的触发条件，
     * 例如：手中物品是否有效、方块是否有空位等。
     * </p>
     *
     * @param blockEntity 目标方块实体
     * @param handStack 玩家手中的物品堆栈
     * @return 如果可以放置物品返回true，否则返回false
     */
    public abstract boolean canPlace(UpPlaceBlockEntity blockEntity, class_1799 handStack);

    /**
     * 定义物品在 {@link UpPlaceBlock} 上放置和取出时的音效配置。
     * <p>
     * 提供三种预置模式：
     * <ul>
     *     <li><b>空音效 {@link #EMPTY}</b>：完全不播放任何声音。</li>
     *     <li><b>动态物品音效 {@link #DYNAMIC}</b>：根据交互的物品类型自动决定声音。
     *         此时记录中的 {@code placeSound} 和 {@code fetchSound} 仅作为动态获取失败时的兜底值。</li>
     *     <li><b>固定音效</b>：通过构造方法直接指定一个固定的 {@link class_3414}，播放时不再动态计算。</li>
     * </ul>
     *
     * @param placeSound 放置时使用的固定音效（动态模式下作为兜底）
     * @param fetchSound 取出时使用的固定音效（动态模式下作为兜底）
     */
    public record UpSounds(class_3414 placeSound, class_3414 fetchSound) {

        /** 空音效：不播放任何声音 */
        public static final UpSounds EMPTY = new UpSounds(null, null);

        /**
         * 动态物品音效：根据交互物品的材质自动选择声音。
         * 兜底音效为石头放置/破坏音效。
         */
        public static final UpSounds DYNAMIC = new UpSounds(
                class_3417.field_14574,
                class_3417.field_15026
        );

        /**
         * 播放固定音效（仅在非动态模式下由 {@link UpPlaceBlockEntity#playSound} 调用）。
         * 如果内部音效为 {@code null} 则不会播放。
         *
         * @param world        当前世界
         * @param pos          播放位置
         * @param isPlaceSound true 播放放置音效，false 播放取出音效
         */
        public void playSound(class_1937 world, class_2338 pos, boolean isPlaceSound) {
            if (isPlaceSound) {
                playPlaceSound(world, pos);
            } else {
                playFetchSound(world, pos);
            }
        }

        /** 播放放置固定音效（服务端，音效非空时） */
        public void playPlaceSound(class_1937 world, class_2338 pos) {
            if (placeSound != null && !world.field_9236) {
                world.method_8396(null, pos, placeSound, class_3419.field_15245, 1.0F, 1.0F);
            }
        }

        /** 播放取出固定音效（服务端，音效非空时） */
        public void playFetchSound(class_1937 world, class_2338 pos) {
            if (fetchSound != null && !world.field_9236) {
                world.method_8396(null, pos, fetchSound, class_3419.field_15245, 1.0F, 1.0F);
            }
        }
    }
}