package org.twcore.api.block;

import org.twcore.api.sound.Item2BlockSounds;

import java.util.List;
import net.minecraft.class_1262;
import net.minecraft.class_1263;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1922;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2371;
import net.minecraft.class_2487;
import net.minecraft.class_2498;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_3414;
import net.minecraft.class_3419;
import net.minecraft.class_3726;
import net.minecraft.class_3965;

/**
 * 放置物品方块实体基类，用于管理方块上的物品放置和取出功能。
 * <p>
 * 该实体实现了{@link class_1263}接口，支持物品的存储和管理，并提供了一套完整的物品放置和取出机制。
 * 子类需要实现特定的物品验证、形状计算和交互逻辑。
 * </p>
 *
 * @see UpPlaceBlock
 */
public abstract class UpPlaceBlockEntity extends class_2586 implements class_1263 {
    /**
     * 物品栏列表，存储方块上放置的所有物品
     */
    protected class_2371<class_1799> inventory;

    public UpPlaceBlockEntity(class_2591<?> type, class_2338 pos, class_2680 state, int inventorySize) {
        super(type, pos, state);
        this.inventory = class_2371.method_10213(inventorySize, class_1799.field_8037);
    }

    @Override
    public void method_11014(class_2487 nbt) {
        super.method_11014(nbt);
        this.inventory = class_2371.method_10213(this.method_5439(), class_1799.field_8037);
        class_1262.method_5429(nbt, this.inventory);
    }

    @Override
    protected void method_11007(class_2487 nbt) {
        super.method_11007(nbt);
        class_1262.method_5426(nbt, this.inventory);
    }

    @Override
    public int method_5439() {
        return inventory.size();
    }

    @Override
    public boolean method_5442() {
        for (class_1799 stack : this.inventory) {
            if (!stack.method_7960()) {
                return false;
            }
        }
        return true;
    }

    @Override
    public class_1799 method_5438(int slot) {
        validateSlotIndex(slot);
        return this.inventory.get(slot);
    }

    @Override
    public class_1799 method_5434(int slot, int amount) {
        validateSlotIndex(slot);
        return class_1262.method_5430(this.inventory, slot, amount);
    }

    @Override
    public class_1799 method_5441(int slot) {
        validateSlotIndex(slot);
        return class_1262.method_5428(this.inventory, slot);
    }

    @Override
    public void method_5447(int slot, class_1799 stack) {
        validateSlotIndex(slot);

        this.inventory.set(slot, stack);
        limitStackSizeIfNeeded(stack);
    }

    @Override
    public void method_5448() {
        this.inventory.clear();
    }

    @Override
    public boolean method_5443(class_1657 player) {
        return true;
    }

    /**
     * 限制物品堆叠大小不超过最大值。
     *
     * @param stack 需要限制堆叠大小的物品堆栈
     */
    protected void limitStackSizeIfNeeded(class_1799 stack) {
        if (stack.method_7947() > this.method_5444()) {
            stack.method_7939(this.method_5444());
        }
    }

    /**
     * 验证槽位索引是否在有效范围内。
     *
     * @param slot 要验证的槽位索引
     * @throws IllegalArgumentException 如果槽位索引超出有效范围
     */
    public void validateSlotIndex(int slot) {
        if (slot < 0 || slot >= this.method_5439()) {
            throw new IllegalArgumentException("Slot " + slot + " not in valid range - [0," + this.method_5439() + ")");
        }
    }

    /**
     * 获取容器中物品的碰撞形状。
     * <p>
     * 该方法用于计算物品在方块世界中的视觉表现和碰撞体积。
     * </p>
     *
     * @param state 当前方块状态
     * @param world 方块所在的世界
     * @param pos 方块位置
     * @param context 形状计算上下文
     * @return 物品的碰撞形状
     */
    public abstract class_265 getContentShape(class_2680 state, class_1922 world, class_2338 pos, class_3726 context);

    /**
     * 验证物品是否可以放入该方块实体的物品栏。
     *
     * @param stack 待验证的物品堆栈
     * @return 如果可以放入返回true，否则返回false
     */
    public abstract boolean isValidItem(class_1799 stack);

    /**
     * 尝试向容器中添加物品。
     * <p>
     * 默认每次添加会消耗数量为1的物品。如果需要不同的消耗数量，
     * 一般需要重写{@link #onPlace(class_2680, class_1937, class_2338, class_1657, class_1268, class_3965, class_1799, List)}方法，
     * 来扣除玩家不同数量的物品
     * </p>
     *
     * @param stack 要添加的物品堆栈
     * @return 操作结果，成功返回{@link class_1269#field_5812}，失败返回{@link class_1269#field_5814}
     */
    public abstract Result tryAddItem(class_1799 stack, class_3965 hit);

    /**
     * 尝试从容器中取出物品。
     *
     * @param player 执行取出操作的玩家
     * @return 操作结果，成功返回{@link class_1269#field_5812}，失败返回{@link class_1269#field_5814}
     */
    public abstract Result tryFetchItem(class_1657 player, class_3965 hit);

    /**
     * 当物品成功取出时调用的回调方法。
     * <p>
     * 默认实现会播放取出音效。子类可以重写此方法来添加自定义逻辑，
     * 如播放粒子效果、执行特殊操作等。如果重写此方法，请确保根据需要
     * 调用父类方法以保持默认的音效行为。
     * </p>
     *
     * @param state 当前方块状态
     * @param world 方块所在的世界
     * @param pos 方块位置
     * @param player 执行取出操作的玩家
     * @param hand 玩家使用的手
     * @param hit 方块击中结果
     * @param fetchStacks 此次取出操作获得的所有物品堆栈
     */
    public void onFetch(class_2680 state, class_1937 world, class_2338 pos, class_1657 player, class_1268 hand, class_3965 hit, List<class_1799> fetchStacks) {
        playSound(world, pos, fetchStacks.get(0), false);
    }

    /**
     * 当物品成功放置时调用的回调方法。
     * <p>
     * 默认实现会播放放置音效并消耗玩家手中1个物品（创造模式除外）。
     * 子类可以重写此方法来添加自定义逻辑。如果重写此方法，请确保根据需要
     * 调用父类方法以保持默认的音效和物品消耗行为。
     * </p>
     *
     * @param state      当前方块状态
     * @param world      方块所在的世界
     * @param pos        方块位置
     * @param player     执行放置操作的玩家
     * @param hand       玩家使用的手
     * @param hit        方块击中结果
     * @param placeStack 放置的物品堆栈
     * @param itemStacks 操作影响的物品堆栈，一般是长度1的placeStack列表
     */
    public void onPlace(class_2680 state, class_1937 world, class_2338 pos, class_1657 player, class_1268 hand, class_3965 hit, class_1799 placeStack, List<class_1799> itemStacks) {
        playSound(world, pos, placeStack, true);

        if (!player.method_7337()) {
            placeStack.method_7934(1);
        }
    }

    /**
     * 统一的音效播放入口。
     * <p>
     * 根据方块上绑定的 {@link UpPlaceBlock.UpSounds} 决定播放策略：
     *
     * @param world        当前世界
     * @param pos          播放位置
     * @param stack        交互的物品堆栈（用于动态声音获取）
     * @param isPlaceSound true 为放置音效，false 为取出音效
     * @see UpPlaceBlock.UpSounds
     */
    protected void playSound(class_1937 world, class_2338 pos, class_1799 stack, boolean isPlaceSound) {
        if (method_11010().method_26204() instanceof UpPlaceBlock upPlaceBlock) {
            UpPlaceBlock.UpSounds sounds = upPlaceBlock.upSounds;

            if (sounds == UpPlaceBlock.UpSounds.EMPTY) {
                return;
            }

            if (sounds == UpPlaceBlock.UpSounds.DYNAMIC) {
                class_3414 sound = getDynamicPlaceSound(stack, isPlaceSound);
                if (sound != null) {
                    world.method_8396(null, pos, sound, class_3419.field_15245, 1.0F, 1.0F);
                }
            } else {
                sounds.playSound(world, pos, isPlaceSound);
            }
        }
    }

    /**
     * 动态获取物品对应的放置/取出音效。
     * <p>
     * 该方法仅在 {@link UpPlaceBlock.UpSounds#DYNAMIC} 模式下被调用。
     * 默认实现：
     * <ul>
     *     <li>从{@link Item2BlockSounds}获取其对应音效组。</li>
     *     <li>否则使用 {@link UpPlaceBlock.UpSounds#DYNAMIC} 中预置的兜底音效。</li>
     * </ul>
     * 子类可以重写此方法以实现完全自定义的动态音效选择逻辑。
     *
     * @param stack        被交互的物品堆栈
     * @param isPlaceSound true 请求放置音效，false 请求取出音效
     * @return 要播放的 {@link class_3414}，返回 {@code null} 则不播放任何声音
     */
    protected class_3414 getDynamicPlaceSound(class_1799 stack, boolean isPlaceSound) {
        class_2498 soundGroup = Item2BlockSounds.getSoundGroup(stack);

        return isPlaceSound ? soundGroup.method_10598() : soundGroup.method_10595();
    }

    /**
     * 获取容器中的第一个物品的类型。
     *
     * @return 容器中第一个物品的类型，如果容器为空则返回null
     */
    public class_1792 getContentItem() {
        class_1799 contentStack = this.method_5438(0);
        return contentStack.method_7960() ? null : contentStack.method_7909();
    }

    /**
     * 检查容器是否已满。
     * <p>
     * 容器已满的条件是所有槽位都有物品且每个物品都达到了最大堆叠数量。
     * </p>
     *
     * @return 如果容器已满返回true，否则返回false
     */
    public boolean isFull() {
        for (int i = 0; i < this.method_5439(); i++) {
            class_1799 stack = this.method_5438(i);
            if (stack.method_7960() || stack.method_7947() < this.method_5444()) {
                return false;
            }
        }
        return true;
    }

    /**
     * 标记方块实体数据已更改，并同步到客户端。
     * <p>
     * 这是一个便捷方法，结合了{@link #method_5431()}和{@link #sync()}的调用。
     * </p>
     */
    public void markDirtyAndSync() {
        this.method_5431();
        this.sync();
    }

    /**
     * 同步方块实体数据到客户端。
     * <p>
     * 当方块实体数据发生变化时调用此方法，确保客户端能够及时更新显示。
     * </p>
     */
    public void sync() {
        if (this.field_11863 != null && !this.field_11863.field_9236) {
            this.field_11863.method_8413(this.field_11867, this.method_11010(), this.method_11010(), 3);
        }
    }

    /**
     * 表示一次操作和取出的结果。
     *
     * @param opsStacks 操作的物品堆栈列表
     * @param result 操作的结果
     */
    public record Result(List<class_1799> opsStacks, class_1269 result) {
        public static Result of(List<class_1799> opsStacks, class_1269 result) {
            return new Result(opsStacks, result);
        }

        public static Result of(class_1269 result) {
            return new Result(List.of(), result);
        }

        public static Result of(class_1799 stack, class_1269 result) {
            return new Result(List.of(stack), result);
        }

        public boolean isAccepted() {
            return result.method_23665();
        }
    }
}