package org.twcore.mixin;

import net.minecraft.class_1268;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_2846;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3225;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.twcore.api.block.HaveClickInteractBlock;

@Mixin(class_3225.class)
public class ServerPlayerInteractionManagerMixin {
    @Shadow
    protected class_3218 world;
    @Shadow
    @Final
    protected class_3222 player;
    @Unique
    private long time = 0;

    @Inject(method = "processBlockBreakingAction", at = @At(value = "INVOKE", target = "Lnet/minecraft/server/network/ServerPlayerInteractionManager;method_41250(Lnet/minecraft/util/math/BlockPos;ZILjava/lang/String;)V", ordinal = 5))
    private void BlockBreakStart(class_2338 pos, class_2846.class_2847 action, class_2350 direction, int worldHeight, int sequence, CallbackInfo ci) {
        time = world.method_8510();
    }

    @Inject(method = "processBlockBreakingAction", at = @At(value = "INVOKE", target = "Lnet/minecraft/server/network/ServerPlayerInteractionManager;method_41250(Lnet/minecraft/util/math/BlockPos;ZILjava/lang/String;)V", ordinal = 8))
    private void BlockBreak(class_2338 pos, class_2846.class_2847 action, class_2350 direction, int worldHeight, int sequence, CallbackInfo ci) {
        long interval = world.method_8510() - time;

        if (interval <= 5 && interval > 0) {
            class_2680 state = world.method_8320(pos);
            if (state.method_26204() instanceof HaveClickInteractBlock haveClickInteractBlock) {
                haveClickInteractBlock.onClickBlock(state, world, pos, player, class_1268.field_5808, direction);
            }
        }
    }
}
