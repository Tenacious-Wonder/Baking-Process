package org.twcore.mixin;

import com.mojang.datafixers.DataFixer;
import net.minecraft.class_3176;
import net.minecraft.class_32;
import net.minecraft.class_3283;
import net.minecraft.class_3807;
import net.minecraft.class_3950;
import net.minecraft.class_6904;
import net.minecraft.class_7497;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.twcore.api.event.TwCoreRegisterEvent;
import org.twcore.config.ConfigManager;

@Mixin(class_3176.class)
public class MinecraftDedicatedServerMixin {

    @Inject(method = "<init>", at = @At(value = "RETURN"))
    private static void coreClientRegistry(Thread serverThread, class_32.class_5143 session, class_3283 dataPackManager, class_6904 saveLoader, class_3807 propertiesLoader, DataFixer dataFixer, class_7497 apiServices, class_3950 worldGenerationProgressListenerFactory, CallbackInfo ci) {
        TwCoreRegisterEvent.TW_CORE_REGISTRAR.invoker().register();

        // 初始化逻辑
        ConfigManager.loadCommon();
    }
}
