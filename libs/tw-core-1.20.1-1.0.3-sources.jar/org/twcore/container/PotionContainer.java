package org.twcore.container;

import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1812;
import net.minecraft.class_1844;
import net.minecraft.class_1847;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.twcore.content.Content;
import org.twcore.registry.Contents;

public class PotionContainer extends AbstractMappedContainer {
    public PotionContainer(ContainerSettings settings) {
        super(settings);
    }

    @Override
    public boolean matches(class_1799 stack) {
        if (stack.method_31574(getEmptyItem()) || supportsItem(stack.method_7909())) {
            return true;
        }

        // 水瓶
        return isWaterPotion(stack);
    }

    @Override
    public boolean canContain(Content content) {
        return content.isIn(Contents.BASE_LIQUID) || content.isIn(Contents.SYRUP);
    }

    @Override
    public @Nullable Content extractContent(class_1799 stack) {
        if (isWaterPotion(stack)) {
            return Contents.WATER;
        }

        return super.extractContent(stack);
    }

    @Override
    public @NotNull class_1799 replaceContent(@NotNull class_1799 stack, @Nullable Content content) {
        if (content != null && content.equals(Contents.WATER)) {
            class_1799 result = new class_1799(class_1802.field_8574, stack.method_7947());
            if (stack.method_7985()) {
                result.method_7980(stack.method_7969());
            }
            return class_1844.method_8061(result, class_1847.field_8991);
        }

        return super.replaceContent(stack, content);
    }

    @Override
    @NotNull
    public class_1799 createItemStack(Content content, int amount) {
        // 特殊处理水瓶
        if (content.equals(Contents.WATER)) {
            class_1799 result = new class_1799(class_1802.field_8574, amount);
            return class_1844.method_8061(result, class_1847.field_8991);
        }

        return super.createItemStack(content, amount);
    }

    /**
     * 检查物品堆是否为水瓶。
     * @param stack 要检查的物品堆
     * @return 如果物品堆是水瓶则返回true，否则返回false
     */
    public static boolean isWaterPotion(class_1799 stack) {
        if (stack.method_7909() instanceof class_1812) {
            return stack.method_31574(class_1802.field_8574) &&
                    class_1844.method_8063(stack) == class_1847.field_8991;
        }
        return false;
    }

    /**
     * @apiNote 如果要调用该方法请先使用isWaterPotion方法检查堆栈是否为水瓶
     */
    @Override
    public boolean supportsItem(class_1792 item) {
        return super.supportsItem(item);
    }
}