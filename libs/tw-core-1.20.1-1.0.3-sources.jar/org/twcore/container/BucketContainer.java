package org.twcore.container;

import net.minecraft.class_1799;
import org.twcore.content.Content;
import org.twcore.registry.Contents;

public class BucketContainer extends AbstractMappedContainer {
    public BucketContainer(ContainerSettings settings) {
        super(settings);
    }

    @Override
    public boolean matches(class_1799 stack) {
        // 检查是否是空桶或支持的桶装物品
        return stack.method_31574(getEmptyItem()) || supportsItem(stack.method_7909());
    }

    @Override
    public boolean canContain(Content content) {
        // 桶可以装基础液体类内容物
        return content.isIn(Contents.BASE_LIQUID);
    }
}